#install.packages("blogdown")
#blogdown::install_hugo()
#blogdown::hugo_version()
#blogdown::new_site()
#blogdown::serve_site() - implement LiveReload so any changes are automatically saved when you edit your source files(Rmarkdown), can also preview website locally 
#config.toml - make changes to global setting, can change URLs
#blogdown::install_theme("nirocfz/https://github.com/slunsford/arabica")
